from local_db import LocalDB
from predict_restaurant import PredictRestaurant
import pandas as pd

def main():
    data = pd.read_csv('./tripadvisor_hotel_reviews.csv')


if __name__ == "__main__":
    main()
